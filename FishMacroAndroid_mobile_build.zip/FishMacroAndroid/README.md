# Fish Macro Android · 초기 소스 프로젝트

이 ZIP은 APK가 아니라 Android Studio에서 열어 빌드하는 Kotlin 소스 프로젝트입니다.

### 포함
- MediaProjection 화면 캡처 서비스
- ML Kit OCR로 `HOLD TO CAST` / `TAP FAST` 문구 감지
- AccessibilityService 기반 길게 누르기 및 연속 터치
- 시작·정지 화면과 권한 안내

### 아직 미완성 / 검증되지 않음
- 충전 게이지 실시간 추적 및 PERFECT 직전 릴리즈
- PERFECT 성공률 60% 이상
- 실제 게임 화면에서 터치 좌표 및 타이밍 보정
- 보상 화면 감지와 재시작 흐름의 안정화
- 실제 기기 빌드 및 실행 테스트

따라서 이 버전은 완성된 자동 낚시 앱이 아니며, 60% 성공률을 보장하지 않습니다. 현재는 OCR 및 기본 터치 연결을 시험하는 출발점입니다.

### 빌드
1. Android Studio와 JDK 17 설치
2. 이 폴더를 Android Studio에서 열기
3. Gradle Sync 실행
4. 기기에 설치 후 접근성 권한 허용
5. 화면 공유 권한을 허용하고 테스트

기본 터치 위치는 화면 중앙에서 약간 아래쪽이며, 누름 시간은 현재 1050ms로 고정되어 있습니다. 실제 게임 UI에 맞춘 좌표/게이지 보정이 필요합니다.


## PC 없이 GitHub에서 APK 빌드하기 (휴대폰 브라우저 사용)

1. GitHub 계정에 로그인합니다.
2. 새 Repository를 만들고 이름을 `FishMacroAndroid`로 지정합니다. 공개/비공개는 편한 쪽을 선택합니다.
3. 이 ZIP의 압축을 풀고, 프로젝트 안의 파일과 `.github` 폴더까지 저장소에 업로드합니다. `.github/workflows/build-apk.yml` 파일 경로가 정확해야 합니다.
4. GitHub 저장소의 `Actions` 탭을 엽니다.
5. `Build Android APK` 작업을 선택하고 `Run workflow`를 누릅니다. main 브랜치에 업로드하면 자동 실행될 수도 있습니다.
6. 작업이 끝나면 성공한 실행 항목을 열고 아래쪽 `Artifacts`에서 `FishMacro-debug-apk`를 다운로드합니다.
7. 다운로드한 ZIP을 휴대폰에서 풀면 `app-debug.apk`가 있습니다. APK를 설치합니다.

빌드는 GitHub의 클라우드 컴퓨터에서 진행되므로 사용자 PC가 필요하지 않습니다. GitHub 계정이 필요하며, 저장소에 소스 코드를 업로드해야 합니다. 이 과정이 성공해도 앱 기능이 실제 게임에서 정상 작동하는지는 별도 테스트가 필요합니다.
