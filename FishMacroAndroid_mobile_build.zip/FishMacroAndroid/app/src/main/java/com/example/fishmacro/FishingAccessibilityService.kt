package com.example.fishmacro

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.view.accessibility.AccessibilityEvent

class FishingAccessibilityService : AccessibilityService() {
    override fun onServiceConnected() { super.onServiceConnected(); instance = this }
    override fun onAccessibilityEvent(event: AccessibilityEvent?) = Unit
    override fun onInterrupt() = Unit

    fun hold(x: Float, y: Float, duration: Long) {
        val path = Path().apply { moveTo(x, y) }
        val stroke = GestureDescription.StrokeDescription(path, 0, duration.coerceAtLeast(100))
        dispatchGesture(GestureDescription.Builder().addStroke(stroke).build(), null, null)
    }

    fun tapBurst(x: Float, y: Float, count: Int = 24) {
        var n = 0
        fun tapNext() {
            if (n >= count) return
            val path = Path().apply { moveTo(x, y) }
            val stroke = GestureDescription.StrokeDescription(path, 0, 45)
            dispatchGesture(GestureDescription.Builder().addStroke(stroke).build(), null, null)
            n++
            if (n < count) android.os.Handler(mainLooper).postDelayed({ tapNext() }, 95)
        }
        tapNext()
    }

    override fun onDestroy() {
        if (instance === this) instance = null
        super.onDestroy()
    }
    companion object {
        @Volatile var instance: FishingAccessibilityService? = null
            private set
    }
}
