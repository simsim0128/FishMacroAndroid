package com.example.fishmacro

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.util.DisplayMetrics
import android.view.WindowManager
import androidx.core.app.NotificationCompat
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import java.nio.ByteBuffer
import java.util.Locale

class ScreenCaptureService : Service() {
    private var projection: MediaProjection? = null
    private var display: android.hardware.display.VirtualDisplay? = null
    private var reader: ImageReader? = null
    private val recognizer by lazy { TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS) }
    private lateinit var thread: HandlerThread
    private lateinit var handler: Handler
    private var busy = false
    private var width = 0
    private var height = 0
    private var phase = Phase.READY

    private enum class Phase { READY, CAST_SENT, TAP_SENT, WAIT_AGAIN }

    override fun onCreate() {
        super.onCreate()
        thread = HandlerThread("FishMacroFrames").also { it.start() }
        handler = Handler(thread.looper)
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(CHANNEL, "Fish Macro", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == STOP) {
            cleanup()
            stopSelf()
            return START_NOT_STICKY
        }
        if (intent?.action == START) {
            val notification = NotificationCompat.Builder(this, CHANNEL)
                .setSmallIcon(android.R.drawable.ic_media_play)
                .setContentTitle("Fish Macro")
                .setContentText("게임 화면 문구를 감지하는 중")
                .setOngoing(true).build()
            if (Build.VERSION.SDK_INT >= 29) {
                startForeground(1, notification,
                    android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
            } else startForeground(1, notification)

            @Suppress("DEPRECATION")
            val data = intent.getParcelableExtra<Intent>(RESULT_DATA)
            if (data == null) { stopSelf(); return START_NOT_STICKY }
            startProjection(intent.getIntExtra(RESULT_CODE, 0), data)
        }
        return START_NOT_STICKY
    }

    private fun startProjection(code: Int, data: Intent) {
        try {
            val wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
            val metrics = DisplayMetrics()
            @Suppress("DEPRECATION")
            wm.defaultDisplay.getRealMetrics(metrics)
            width = metrics.widthPixels
            height = metrics.heightPixels
            val manager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            projection = manager.getMediaProjection(code, data)
            projection?.registerCallback(object : MediaProjection.Callback() {
                override fun onStop() { cleanup(); stopSelf() }
            }, handler)
            reader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 2)
            display = projection?.createVirtualDisplay("FishMacro", width, height,
                metrics.densityDpi, 0, reader?.surface, null, handler)
            handler.post(scan)
        } catch (_: Exception) {
            stopSelf()
        }
    }

    private val scan = object : Runnable {
        override fun run() {
            if (reader == null) return
            if (!busy) {
                val image = try { reader?.acquireLatestImage() } catch (_: Exception) { null }
                if (image != null) {
                    val bitmap = toBitmap(image)
                    image.close()
                    if (bitmap != null) {
                        busy = true
                        recognizer.process(InputImage.fromBitmap(bitmap, 0))
                            .addOnSuccessListener { result -> detect(result.text) }
                            .addOnCompleteListener { bitmap.recycle(); busy = false }
                    }
                }
            }
            handler.postDelayed(this, 500)
        }
    }

    private fun detect(raw: String) {
        val text = raw.uppercase(Locale.ROOT).replace("\\s+".toRegex(), " ")
        val touch = FishingAccessibilityService.instance ?: return
        when {
            text.contains("HOLD TO CAST") && (phase == Phase.READY || phase == Phase.WAIT_AGAIN) -> {
                phase = Phase.CAST_SENT
                touch.hold(width * 0.5f, height * 0.62f, 1050)
                handler.postDelayed({ if (phase == Phase.CAST_SENT) phase = Phase.WAIT_AGAIN }, 1400)
            }
            text.contains("TAP FAST") && phase != Phase.TAP_SENT -> {
                phase = Phase.TAP_SENT
                touch.tapBurst(width * 0.5f, height * 0.62f)
                handler.postDelayed({ if (phase == Phase.TAP_SENT) phase = Phase.WAIT_AGAIN }, 2800)
            }
        }
        if (text.contains("PERFECT")) {
            // 현재는 문구 감지만 수행합니다. 게이지 위치/목표 구간 추적은 미구현입니다.
        }
    }

    private fun toBitmap(image: Image): Bitmap? = try {
        val plane = image.planes[0]
        val pixelStride = plane.pixelStride
        val rowStride = plane.rowStride
        val padding = rowStride - pixelStride * image.width
        val wide = Bitmap.createBitmap(image.width + padding / pixelStride,
            image.height, Bitmap.Config.ARGB_8888)
        val buffer: ByteBuffer = plane.buffer
        buffer.rewind()
        wide.copyPixelsFromBuffer(buffer)
        val result = Bitmap.createBitmap(wide, 0, 0, image.width, image.height)
        wide.recycle()
        result
    } catch (_: Exception) { null }

    private fun cleanup() {
        handler.removeCallbacksAndMessages(null)
        try { display?.release() } catch (_: Exception) {}
        display = null
        try { reader?.close() } catch (_: Exception) {}
        reader = null
        try { projection?.stop() } catch (_: Exception) {}
        projection = null
        stopForeground(STOP_FOREGROUND_REMOVE)
    }

    override fun onDestroy() {
        cleanup()
        try { recognizer.close() } catch (_: Exception) {}
        if (::thread.isInitialized) thread.quitSafely()
        super.onDestroy()
    }
    override fun onBind(intent: Intent?) = null

    companion object {
        const val START = "fishmacro.START"
        const val STOP = "fishmacro.STOP"
        const val RESULT_CODE = "result_code"
        const val RESULT_DATA = "result_data"
        private const val CHANNEL = "fishmacro_capture"
    }
}
