package com.example.fishmacro

import android.app.Activity
import android.content.ComponentName
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.os.Bundle
import android.provider.Settings
import android.text.TextUtils
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.content.ContextCompat

class MainActivity : Activity() {
    private val requestCode = 4201
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(28, 36, 28, 24)
        }
        layout.addView(TextView(this).apply {
            text = "Fish Macro · Android prototype"
            textSize = 22f
        })
        status = TextView(this).apply {
            text = "상태: 대기 중"
            textSize = 16f
            setPadding(0, 20, 0, 20)
        }
        layout.addView(status)
        layout.addView(button("접근성 권한 설정") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        })
        layout.addView(button("화면 공유 및 감지 시작") {
            if (!isAccessibilityEnabled()) {
                status.text = "먼저 접근성 권한을 켜 주세요."
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            } else {
                val manager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
                startActivityForResult(manager.createScreenCaptureIntent(), requestCode)
            }
        })
        layout.addView(button("정지") {
            startService(Intent(this, ScreenCaptureService::class.java).setAction(ScreenCaptureService.STOP))
            status.text = "상태: 정지 요청"
        })
        layout.addView(TextView(this).apply {
            text = "현재 버전은 HOLD TO CAST / TAP FAST 문구 감지와 기본 터치 흐름을 시험하는 초기판입니다. PERFECT 게이지 추적 및 60% 성공률은 아직 구현·검증되지 않았습니다."
            textSize = 14f
            setPadding(0, 20, 0, 0)
        })
        setContentView(layout)
    }

    private fun button(label: String, action: () -> Unit) = Button(this).apply {
        text = label
        isAllCaps = false
        setOnClickListener { action() }
    }

    private fun isAccessibilityEnabled(): Boolean {
        val expected = ComponentName(this, FishingAccessibilityService::class.java).flattenToString()
        val enabled = Settings.Secure.getString(contentResolver,
            Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: return false
        val splitter = TextUtils.SimpleStringSplitter(':')
        splitter.setString(enabled)
        return splitter.any { it.equals(expected, true) }
    }

    @Deprecated("Platform activity result for broad compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == this.requestCode) {
            if (resultCode == RESULT_OK && data != null) {
                val i = Intent(this, ScreenCaptureService::class.java).apply {
                    action = ScreenCaptureService.START
                    putExtra(ScreenCaptureService.RESULT_CODE, resultCode)
                    putExtra(ScreenCaptureService.RESULT_DATA, data)
                }
                ContextCompat.startForegroundService(this, i)
                status.text = "상태: 화면 감지 시작 중"
            } else status.text = "화면 공유가 취소되었습니다."
        }
    }
}
